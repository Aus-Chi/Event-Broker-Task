package com.solace.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.solacesystems.jcsmp.EndpointProperties;
import com.solacesystems.jcsmp.JCSMPException;
import com.solacesystems.jcsmp.JCSMPFactory;
import com.solacesystems.jcsmp.JCSMPProperties;
import com.solacesystems.jcsmp.JCSMPSession;
import com.solacesystems.jcsmp.JCSMPStreamingPublishEventHandler;
import com.solacesystems.jcsmp.Queue;
import com.solacesystems.jcsmp.TextMessage;
import com.solacesystems.jcsmp.XMLMessageProducer;

@SpringBootApplication
public class EventBrokerDemoPublisher1Application {

	public static void main(String[] args) {
		SpringApplication.run(EventBrokerDemoPublisher1Application.class, args);

		final JCSMPProperties properties = new JCSMPProperties();
		properties.setProperty(JCSMPProperties.HOST, "tcps://mr-connection-c0xzrfc29qu.messaging.solace.cloud:55443");
		properties.setProperty(JCSMPProperties.USERNAME, "solace-cloud-client");
		properties.setProperty(JCSMPProperties.PASSWORD, "2gvs1guu1qapdbvtpa8v7rntls");
		properties.setProperty(JCSMPProperties.VPN_NAME, "austin-s-demo-event-broker");
		JCSMPSession session = null;

		try {
			session = JCSMPFactory.onlyInstance().createSession(properties);
			session.connect();

			final EndpointProperties endpointProps = new EndpointProperties();
			endpointProps.setPermission(EndpointProperties.PERMISSION_READ_ONLY);
			endpointProps.setAccessType(EndpointProperties.ACCESSTYPE_EXCLUSIVE);

			XMLMessageProducer prod = session.getMessageProducer(new JCSMPStreamingPublishEventHandler() {

				@Override
				public void responseReceived(String messageID) {
					System.out.println("Producer received response for msg: " + messageID);
				}

				@Override
				public void handleError(String messageID, JCSMPException e, long timestamp) {
					System.out.printf("Producer received error for msg: %s@%s - %s%n", messageID, timestamp, e);
				}
			});

			TextMessage message = JCSMPFactory.onlyInstance().createMessage(TextMessage.class);
			Queue destinationQueue = JCSMPFactory.onlyInstance().createQueue("my-new-queue");
			session.provision(destinationQueue, endpointProps, JCSMPSession.FLAG_IGNORE_ALREADY_EXISTS);
			for (int i = 1; i <= 3; i++) {
				message.setText("This is publisher 1 - message " + i);

				prod.send(message, destinationQueue);
			}
			prod.close();
			session.closeSession();

		} catch (JCSMPException e) {
			e.printStackTrace();
		}

	}

}
