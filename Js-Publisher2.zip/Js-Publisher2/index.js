const path = require("path");
const solclientjs = path.resolve(
  __dirname,
  "./solclientjs-10.17.1/lib/solclient.js"
);
module.exports = {
  resolve: {
    alias: {
      solclientjs$: solclientjs,
    },
  },
  module: {
    rules: [
      {
        test: require.resolve(solclientjs),
        use: "exports-loader?window.solace",
      },
    ],
  },
};

const solace = require("solclientjs");

let factoryProps = new solace.SolclientFactoryProperties();
factoryProps.profile = solace.SolclientFactoryProfiles.version10;
solace.SolclientFactory.init(factoryProps);

let session = solace.SolclientFactory.createSession({
  url: "wss://mr-connection-c0xzrfc29qu.messaging.solace.cloud:443",
  vpnName: "austin-s-demo-event-broker",
  userName: "solace-cloud-client",
  password: "2gvs1guu1qapdbvtpa8v7rntls",
});
try {
  session.connect();
} catch (error) {
  console.log(error);
}
let message = solace.SolclientFactory.createMessage();
message.setDestination(
  solace.SolclientFactory.createDurableQueueDestination("my-new-queue")
);
message.setDeliveryMode(solace.MessageDeliveryModeType.PERSISTENT);
for (let i = 4; i <= 5; i++) {
  let messageText = "This is publisher 2 - message " + i;

  message.setBinaryAttachment(messageText);

  try {
    session.send(message);
  } catch (error) {}
}
